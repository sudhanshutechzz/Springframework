package com.cg.core.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.core.Exception.EmpException;
import com.cg.core.dao.Empdao;
import com.cg.core.dto.Emp;

@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService{
	@Autowired
	public Empdao dao;
	@Override
	public String authenticate(String userNm, String passwd) {
		if(userNm.equals("aa") && (passwd.equals("bb")))
		return "aa bb cc";
		return null;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		
		return dao.getEmpList();
	}

}
