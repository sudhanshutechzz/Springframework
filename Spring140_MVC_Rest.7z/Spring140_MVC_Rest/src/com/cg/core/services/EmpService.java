package com.cg.core.services;

import java.util.List;

import com.cg.core.Exception.EmpException;
import com.cg.core.dto.Emp;

public interface EmpService {
public String authenticate(String userNm,String passwd);
public List<Emp> getEmpList() throws EmpException;
}
