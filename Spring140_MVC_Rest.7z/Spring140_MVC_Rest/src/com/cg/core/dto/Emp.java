package com.cg.core.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Emp {
@Id
@Column(name="EMPID")
private int empId;
@Column(name="EMPNAME")
private String firstName;
@Column(name="SALARY")
private float salary;
@Column(name="CITY")
private String city;


public Emp(int empId, String firstName, float salary, String city) {
	super();
	this.empId = empId;
	this.firstName = firstName;
	this.salary = salary;
	this.city = city;
}


public Emp()
{}


@Override
public String toString() {
	return "Emp [empId=" + empId + ", firstName=" + firstName + ", salary=" + salary + ", city=" + city + "]";
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public float getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}
