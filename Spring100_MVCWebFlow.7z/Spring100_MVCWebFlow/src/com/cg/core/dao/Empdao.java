package com.cg.core.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.core.Exception.EmpException;
import com.cg.core.dto.Emp;

public interface Empdao {
public List<Emp> getEmpList() throws EmpException;
}
