package com.cg.core.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.core.Exception.EmpException;
import com.cg.core.dto.Emp;
/*
 * Using connection pool is always abest practice instead of managing single connection
 * Spring support javax.sql.DataSource which is manager for pool of connection
 * A DataSource Mangaer in spring gives ready connection poool and datasource
 */
@Repository
public class EmpdaoImpl implements Empdao {
	@Autowired
	private DataSource dataSource;
	@Override
	public List<Emp> getEmpList() throws EmpException {
		Connection connect=null;
		Statement stmt=null;
		ResultSet rs=null;
		String qry="Select EMPID,EMPNAME,SALARY,CITY from employee";
		List<Emp> empList=new ArrayList<>();
		try
		{
		connect=dataSource.getConnection();
		stmt=connect.createStatement();
		rs=stmt.executeQuery(qry);
		while(rs.next())
		{
			int empNo=rs.getInt("EMPID");
			String empname=rs.getString("EMPNAME");
			float sal=rs.getFloat("SALARY");
			String city=rs.getString("CITY");
			Emp emp=new Emp(empNo,empname,sal,city);
			empList.add(emp);
		}
		}
		catch(SQLException e)
		{ throw new EmpException("Error while procuring data.",e);
			
		}
		finally
		{
			try {
				if(rs!=null)
					rs.close();
				if(stmt!=null)
				{
					stmt.close();
				}
				if(connect!=null)
				{
					connect.close();//it will return the connection back to pool.
				}
			} catch (SQLException e) {
				throw new EmpException("Error while closing connection.",e);
			}
		}
		return empList;
	}

}
