package com.cg.core.services;


@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService{

	@Override
	public String authenticate(String userNm, String passwd) {
		if(userNm.equals("aa") && (passwd.equals("bb")))
		return "aa bb cc";
		return null;
	}

}
