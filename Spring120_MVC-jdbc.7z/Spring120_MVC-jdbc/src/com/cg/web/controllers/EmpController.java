package com.cg.web.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.services.EmpService;
//http://localhost:9090/Spring100_MVCWebFlow/empService/home.do
@Controller
@RequestMapping("/empService")
public class EmpController {
	@Autowired
	private EmpService service;
	@RequestMapping("/home.do")
	public String getHomePage()
	{
		return "Home";
	}
	@RequestMapping("/login.do")
	public String getLoginPage()
	{
		return "Login";
	}
	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(@RequestParam("userName") String userName,
			@RequestParam("Password")String Password)
	{	/*String userName=req.getParameter("userName");
		String password=req.getParameter("Password");*/
		String fullName=service.authenticate(userName, Password);
		ModelAndView mAndV=null;
		if(fullName!=null)
		{mAndV=new ModelAndView("MainMenu");
		mAndV.addObject("fullName",fullName);}
		else
		{mAndV=new ModelAndView("Login");
		mAndV.addObject("msg","Authentication failed. pls do again");	}
		return mAndV;
	}
	

}
